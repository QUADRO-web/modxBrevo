
brevo

Author: Jan Dähne <https://www.quadro.digital>
Copyright 2025

Official Documentation: https://www.quadro.digital/modx-extras/brevo

Bugs and Feature Requests: https://github.com/QUADRO-web/modxBrevo

Questions: http://forums.modx.com

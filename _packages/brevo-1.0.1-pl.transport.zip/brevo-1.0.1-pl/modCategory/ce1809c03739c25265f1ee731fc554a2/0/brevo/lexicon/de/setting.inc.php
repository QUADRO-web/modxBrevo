<?php
/**
 * Setting Lexicon Entries
 *
 * @package brevo
 * @subpackage lexicon
 */
$_lang['setting_brevo.api_key'] = 'Api-Key';

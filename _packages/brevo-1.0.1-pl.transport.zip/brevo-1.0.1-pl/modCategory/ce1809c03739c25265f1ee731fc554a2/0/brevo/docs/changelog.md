Changelog for brevo

brevo 1.0.1
---------------------------------
+ Fix subscription hook

brevo 1.0.0
---------------------------------
+ initial Setup
